class Sub{
 public static void Sub(int a)
{
System.out.println( a-3);
}
 public static void Sub(int a,int b)
{
System.out.println(a-b);
}
 public static void Sub(int a, int b ,int c)
{
System.out.println(a-b-c);
}
public static void main(String [] args)
{
Sub(10);
Sub(15,2);
Sub(93,12,8);
}
}

