class Login {

    // Login with username only
    public static void login(String username) {
        System.out.println("Login successful with username: " + username);
    }

    // Login with username and password
    public static void login(String username, String password) {
        System.out.println("Login successful with Password: " + password);
    }

    // Login with username, password and OTP
    public static void login(String username, String password, int otp) {
        System.out.println("Login successful with OTP: " + otp);
    }

    public static void main(String[] args) {

        login("muskan");
        login("muskan", "12345");
        login("muskan", "12345", 7890);
    }
}
