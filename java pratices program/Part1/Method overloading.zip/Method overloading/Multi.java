class Multi{
 public static void Mul(int a)
{
System.out.println( a*3);
}
 public static void Mul(int a,int b)
{
System.out.println(a*b);
}
 public static void Mul(int a, int b ,int c)
{
System.out.println(a*b*c);
}
public static void main(String [] args)
{
Mul(10);
Mul(15,2);
Mul(93,12,8);
}
}

