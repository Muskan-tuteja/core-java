class Prog3{
  public static void main(String[] args){
    float[] a = {5,9,6,5,9,8};
    System.out.println(a);
    System.out.println(a.length);
    System.out.println(a[3]);
a[1] = 7;
System.out.println(a[1]);
  System.out.println(a);
  }
}