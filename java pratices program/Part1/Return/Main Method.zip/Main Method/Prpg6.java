class Prpg6{
  public static void main(String[] args){
    Short[] a = {(short)5, (short)9, (short)6, (short)5, (short)9, (short)8};
    System.out.println(a);
    System.out.println(a.length);
    System.out.println(a[3]);

    //System.out.println(a[9]);

a[1] = 9;
a[2] = 89;
a[3] = 100;
System.out.println(a[1]);
System.out.println(a[2]);
System.out.println(a[3]);
  System.out.println(a);
  }
}