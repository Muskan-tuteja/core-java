class Prog1{
  public static void main(String[] args){
    int[] a = {2,3,4,5,9,0};
    System.out.println(a);
    System.out.println(a.length);
    System.out.println(a[3]);
a[0] = 100;
a[1] = 110;
a[2] = 200;
a[3] = 1500;
System.out.println(a[1]);
System.out.println(a[0]);
System.out.println(a[2]);
System.out.println(a[3]);
  System.out.println(a);
  }
}