class Prog9{
  public static void main(String[] args){
        String[] a = {"tru", "mjik", "mkilo", "false"};
    System.out.println(a);
    System.out.println(a.length);
    System.out.println(a[3]);

    //System.out.println(a[9]);

        a[0] = "Muskan";
        a[3] = "Isha";

        System.out.println(a[0]);
        System.out.println(a[2]);
        System.out.println(a[3]);  System.out.println(a);
  }
}