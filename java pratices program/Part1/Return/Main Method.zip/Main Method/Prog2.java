class Prog2{
  public static void main(String[] args){
    char[] a = {'A','E','G','H'};
    System.out.println(a);
    System.out.println(a.length);
    System.out.println(a[3]);
a[1] = 'Q';
System.out.println(a[1]);
  System.out.println(a);
  }
}